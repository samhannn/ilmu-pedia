<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class MateriPage extends Model
{
    protected $guarded = [];
}